FOLLOW THE INSTRUCTIONS TO THE LETTER OR YOU WILL BE UNABLE TO ENJOY THIS MOD!

## How to install
1. Extract the contents of the mod to the DLLMods folder inside your Software Inc. directory.
2. Start up your game. If you haven't already bound your key to opening console, do so by going to Settings -> Keys, and then bind "Open Console" to a key of your choosing. (You might not have to do this, but do it just in case.)
3. Activate the in-game console and type "RELOAD_DLL_MOD EducationBuff2" without quotes.
4. Activate the mod in the Mod section of settings.
5. Enjoy!